#include <jni.h>
#include <string>
#include <sys/time.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <chrono>

static long long time_offset_ms = 0;
#define NTP_TIMESTAMP_DELTA 2208988800ull

extern "C" JNIEXPORT jlong JNICALL
Java_com_example_seckillcloc_NativeTime_syncNtpServer(JNIEnv *env, jobject thiz, jstring host_) {
    const char *host = env->GetStringUTFChars(host_, nullptr);
    struct sockaddr_in serv_addr;
    int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sockfd < 0) {
        env->ReleaseStringUTFChars(host_, host);
        return 0;
    }
    struct timeval tv{2, 0};
    setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv, sizeof(tv));
    struct hostent *server = gethostbyname(host);
    if (!server) { close(sockfd); env->ReleaseStringUTFChars(host_, host); return 0; }

    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    memcpy(&serv_addr.sin_addr.s_addr, server->h_addr, server->h_length);
    serv_addr.sin_port = htons(123);

    unsigned long msg[12] = {0};
    msg[0] = htonl(0x1B000000);
    auto t1 = std::chrono::high_resolution_clock::now();
    sendto(sockfd, (char*)msg, sizeof(msg), 0, (struct sockaddr*)&serv_addr, sizeof(serv_addr));
    if (recv(sockfd, (char*)msg, sizeof(msg), 0) < 0) { close(sockfd); env->ReleaseStringUTFChars(host_, host); return 0; }
    auto t2 = std::chrono::high_resolution_clock::now();
    close(sockfd);
    env->ReleaseStringUTFChars(host_, host);

    unsigned long tntp = ntohl(msg[40]);
    unsigned long long ntp_time_ms = ((unsigned long long)tntp - NTP_TIMESTAMP_DELTA) * 1000ULL;
    long long rtt_ms = std::chrono::duration_cast<std::chrono::milliseconds>(t2 - t1).count();
    long long current_local_ms = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();

    time_offset_ms = (ntp_time_ms + (rtt_ms / 2)) - current_local_ms;
    return time_offset_ms;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_example_seckillcloc_NativeTime_getNativeTimestamp(JNIEnv *env, jobject thiz) {
    struct timeval tv;
    gettimeofday(&tv, nullptr);
    return ((long long)tv.tv_sec * 1000LL + (long long)tv.tv_usec / 1000LL) + time_offset_ms;
}