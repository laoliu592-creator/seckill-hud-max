package com.example.seckillcloc

object NativeTime {
    init { System.loadLibrary("seckillcloc") }
    external fun getNativeTimestamp(): Long
    external fun syncNtpServer(host: String): Long
}