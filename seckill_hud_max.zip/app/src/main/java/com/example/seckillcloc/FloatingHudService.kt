package com.example.seckillcloc

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Choreographer
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

class FloatingHudService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var hudView: TextView
    private val formatter = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())
    private var timeOffsetMs: Int = 0
    private var isAutoMode: Boolean = false
    private var hasFired: Boolean = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            val currentTs = NativeTime.getNativeTimestamp() + timeOffsetMs
            val msPart = currentTs % 60000
            hudView.text = formatter.format(Date(currentTs))

            if (msPart > 59000) {
                hudView.setTextColor(Color.parseColor("#FF3B30"))
                if (isAutoMode && !hasFired && msPart > 59980) {
                    hasFired = true
                    val location = IntArray(2)
                    hudView.getLocationOnScreen(location)
                    AutoSniperService.instance?.executeAutoClick(
                        location[0] + (hudView.width / 2f),
                        location[1] + (hudView.height / 2f)
                    )
                    hudView.text = "FIRE!"
                }
            } else {
                hudView.setTextColor(Color.parseColor("#00FF00"))
                hasFired = false
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        hudView = TextView(this).apply {
            textSize = 28f
            setShadowLayer(4f, 2f, 2f, Color.BLACK)
            typeface = android.graphics.Typeface.MONOSPACE
        }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        wm.addView(hudView, p)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let {
            timeOffsetMs = it.getIntExtra("TIME_OFFSET", 0)
            isAutoMode = it.getBooleanExtra("AUTO_MODE", false)
        }
        Choreographer.getInstance().removeFrameCallback(frameCallback)
        Choreographer.getInstance().postFrameCallback(frameCallback)
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onDestroy() {
        super.onDestroy()
        Choreographer.getInstance().removeFrameCallback(frameCallback)
        if (::hudView.isInitialized) wm.removeView(hudView)
    }
    override fun onBind(i: Intent?): IBinder? = null
}