package com.example.seckillcloc

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class TimeSource(val name: String, val host: String)
val TIME_SOURCES = listOf(
    TimeSource("淘宝 / 天猫", "api.m.taobao.com"),
    TimeSource("京东", "api.m.jd.com")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    TacticalSettingsScreen(
                        onDeploy = { source, offsetMs, isAuto -> deployHud(source, offsetMs, isAuto) },
                        onTerminate = { stopService(Intent(this, FloatingHudService::class.java)) }
                    )
                }
            }
        }
    }

    private fun deployHud(source: TimeSource, userOffset: Int, isAutoMode: Boolean) {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (isAutoMode && AutoSniperService.instance == null) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }

        lifecycleScope.launch(Dispatchers.IO) {
            val ntpOffset = NativeTime.syncNtpServer("ntp.aliyun.com")
            val httpOffset = TimeSynchronizer.syncHttpOffset("https://${source.host}")
            val networkOffset = if (httpOffset != 0L) httpOffset else ntpOffset
            val finalOffset = networkOffset + userOffset

            withContext(Dispatchers.Main) {
                val intent = Intent(this@MainActivity, FloatingHudService::class.java).apply {
                    putExtra("TIME_OFFSET", finalOffset.toInt())
                    putExtra("AUTO_MODE", isAutoMode)
                }
                startService(intent)
                moveTaskToBack(true)
            }
        }
    }
}

@Composable
fun TacticalSettingsScreen(onDeploy: (TimeSource, Int, Boolean) -> Unit, onTerminate: () -> Unit) {
    var selectedSource by remember { mutableStateOf(TIME_SOURCES[0]) }
    var offsetMs by remember { mutableStateOf(0f) }
    var isAutoMode by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("SECKILL HUD MAX", fontSize = 32.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(24.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("目标时源 (Time Source)", fontWeight = FontWeight.Bold)
                TIME_SOURCES.forEach { source ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = (source == selectedSource), onClick = { selectedSource = source })
                        Text(source.name)
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("网络延迟补偿: ${offsetMs.toInt()} ms", fontWeight = FontWeight.Bold)
                Slider(value = offsetMs, onValueChange = { offsetMs = it }, valueRange = -500f..500f, steps = 100)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("自动开火模式", fontWeight = FontWeight.Bold)
                    Text(if (isAutoMode) "到点由无障碍内核自动点击" else "仅视觉提示，手动点击", fontSize = 12.sp)
                }
                Switch(checked = isAutoMode, onCheckedChange = { isAutoMode = it })
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { onDeploy(selectedSource, offsetMs.toInt(), isAutoMode) },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        ) {
            Text("DEPLOY / 终极部署", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedButton(
            onClick = onTerminate,
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            Text("TERMINATE / 关闭服务", fontSize = 18.sp)
        }
    }
}