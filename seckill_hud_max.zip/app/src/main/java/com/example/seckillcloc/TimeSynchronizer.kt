package com.example.seckillcloc

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

object TimeSynchronizer {
    private val gmtFormat = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("GMT")
    }
    suspend fun syncHttpOffset(targetUrl: String): Long = withContext(Dispatchers.IO) {
        try {
            val t1 = System.currentTimeMillis()
            val conn = (URL(targetUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "HEAD"; connectTimeout = 3000; readTimeout = 3000
            }
            conn.connect()
            val dateHeader = conn.getHeaderField("Date")
            val t2 = System.currentTimeMillis()
            conn.disconnect()
            if (dateHeader != null) {
                val serverTime = gmtFormat.parse(dateHeader)?.time ?: return@withContext 0L
                return@withContext (serverTime + ((t2 - t1) / 2)) - t2
            }
        } catch (e: Exception) { e.printStackTrace() }
        return@withContext 0L
    }
}